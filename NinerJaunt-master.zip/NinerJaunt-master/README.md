# NinerJaunt
Software Engineering 6112 Project - A route app to help people get around UNC Charlotte's campus.

Team:

Noah Shaw - nshaw6@uncc.edu - Team Lead

Saurabh Burange - sburange@uncc.edu

Priyen Yatinbhai Dang - pdang2@uncc.edu

Rahel Paul Fargose - rfargose@uncc.edu

Talazia Moore - tmoor126@uncc.edu

Matt Wells - mwells21@uncc.edu
